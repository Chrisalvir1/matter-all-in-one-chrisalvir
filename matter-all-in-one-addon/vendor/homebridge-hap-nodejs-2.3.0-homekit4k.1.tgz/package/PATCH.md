# HomeKit 4K HAP compatibility package

HomeKit 4K uses **official `@homebridge/hap-nodejs@2.3.0` as its runtime base**.
The vendored package is identified as `2.3.0-homekit4k.1` so diagnostics can
distinguish the upstream release from the HomeKit 4K compatibility layer.

The runtime is rebuilt deterministically by
`scripts/rebase-hap-nodejs-230.mjs` and `scripts/build-vendored-hap.mjs`.
The official 2.3.0 npm package supplies the complete ESM distribution and all
upstream fixes. HomeKit 4K then applies only the compatibility extensions that
are not present upstream.

## Secure Video compatibility layer

The Secure Video source layer originates from the Apache-2.0 Camera.UI
Secure Video work in
`seydx/HAP-NodeJS@f844d293d62d843d7c7d5e9363bb606fd841ee00`, but it is
compiled **on top of the official HAP-NodeJS 2.3.0 ESM runtime** rather than
replacing 2.3.0 with the older fork.

It retains the HomeKit 4K contracts required by v0.6.31:

- `SecureVideoController`;
- WebRTC and Multi-Tier RTP management;
- H.264 classic RTP compatibility alongside Secure Video;
- HEVC/HKSV3 service definitions and TLV codecs;
- HDS snapshots and recording transport;
- CMAF ingest support;
- SFrame/SRTP integration points used by the plugin;
- stable controller serialization/deserialization and service maps;
- the existing Camera.UI delegates and source-selection behavior.

The v0.6.31 compatibility wiring is preserved explicitly: WebRTC and
Multi-Tier RTP services remain linked to the recording/data-stream and
operating-mode services, the classic RTP service remains available when a
streaming delegate is supplied, and streaming status changes continue to be
propagated to all active HomeKit streaming paths.

## Pairing and persistent state

The migration does **not** change HomeKit usernames, accessory UUIDs, setup
codes, QR payloads, Camera.UI camera IDs or the plugin's storage locations.
Existing pairing/controller files remain in their current format.

Four persistence protections from v0.6.31 are rebased onto the 2.3.0 source
instead of copying the old 2.2.3 files:

- `HAPFileStorage` avoids rewriting byte-identical state only after checking
  the actual file on disk. Missing, changed or unreadable files still require a
  real successful write.
- `ControllerStorage` retains the last durable controller state during
  ENOSPC, EDQUOT and related recoverable I/O failures and retries the latest
  state with bounded exponential backoff.
- `AccessoryInfo` rolls configuration metadata back if its durable save
  fails, without pretending that new pairing information was written.
- `Accessory` retries background configuration persistence/advertisement and
  cancels pending retries when the accessory is unpublished.

Direct security-sensitive pairing saves still fail visibly when storage cannot
persist them. No process-wide exception handler and no fake successful write
are installed.

## ChaCha20-Poly1305

The upstream 2.3.0 `hapCrypto` implementation is retained, including its HAP
framing behavior, and HomeKit 4K adds its provider abstraction:

- `NATIVE`: Node.js `node:crypto`;
- `PORTABLE`: RFC 8439 ChaCha20-Poly1305 from `@noble/ciphers`;
- `UNAVAILABLE`: fail closed.

`HOMEKIT4K_HAP_CRYPTO_PROVIDER` continues to support `auto`, `native`,
`portable` and `off`. Authentication failures are returned before
plaintext is exposed.

## CMAF compatibility patch

The CMAF client retains the v0.6.31 behavior of sending DASH-IF Interface 1
init/media fMP4 boxes unchanged over the provisioned mTLS connection. It does
not wrap MP4 objects in the older external IV/ciphertext/tag envelope that was
rejected by the publishing point.

Physical acceptance by Apple Home remains an empirical validation gate.

## Build and verification

HAP-NodeJS 2.3.0 is ESM. The Secure Video and HomeKit 4K patches are maintained
as TypeScript source overlays and compiled into the same ESM runtime during the
build. A full CommonJS mirror is generated only inside the installed test
runtime for deterministic filesystem-fault injection; that mirror is not
bundled or published.

The migration workflow uses Node.js **26.13.0 LTS**, fetches the official
`@homebridge/hap-nodejs@2.3.0` package, applies the compatibility layer,
regenerates the lockfile, and requires all of the following before the generated
vendor runtime may be committed:

- `pnpm check`;
- Camera.UI bundle build;
- bundle smoke test;
- test coverage;
- runtime invariants for HAP version, Secure Video exports and crypto provider;
- plugin version remains `0.6.31` during this migration.

The verified automated run completed 286 tests with **278 passed, 0 failed and
8 skipped**. The skipped cases are host/media-dependent and do not replace the
final physical Camera.UI/Apple Home validation.

Upstream HAP copyright and the Apache-2.0 `LICENSE` are retained. The portable
provider dependency retains its own MIT license.
